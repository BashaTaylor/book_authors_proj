from django.apps import AppConfig


class DojoSurveyRevisitedAppConfig(AppConfig):
    name = 'dojo_survey_revisited_app'
