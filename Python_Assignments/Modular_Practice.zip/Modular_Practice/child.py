import parent

print(locals())

