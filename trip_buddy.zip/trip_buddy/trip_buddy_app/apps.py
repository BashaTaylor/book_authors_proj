from django.apps import AppConfig


class TripBuddyAppConfig(AppConfig):
    name = 'trip_buddy_app'
