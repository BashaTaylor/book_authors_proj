from django.apps import AppConfig


class HandyHelperAppConfig(AppConfig):
    name = 'handy_helper_app'
