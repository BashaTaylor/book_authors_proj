from django.db import models
import re
from django.db.models.deletion import CASCADE

# Create your models here.

class UserManager(models.Manager):
    def create_validator(self, reqPOST):
        errors = {}
        #validate the length of the first name, last name, password
        if len(reqPOST['first_name']) < 2:
            errors['first_name'] = 'First name requires at least 2 characters.'
        if len(reqPOST['last_name']) < 2:
            errors['last_name'] = 'Last name requires at least 2 characters.'    
        if len(reqPOST['email']) < 6:
            errors['email'] = 'Email requires at least 6 characters.'
        if len(reqPOST['password']) < 8:
            errors['password'] = 'Password requires at least 8 characters.'
        if reqPOST['password'] != reqPOST['confirm_pw']:
            errors['match']='Incorrect password or confirmation.'
        EMAIL_REGEX=re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(reqPOST['email']):
            errors['regex']=("Invalid email address!")
        users_with_email=User.objects.filter(email=reqPOST['email'])
        # this would return a list
        # you can't use the same email
        if len(users_with_email) >= 1:
            errors['dup']='Email taken, use other email'
        return errors
class JobManager(models.Manager):
    def job_validator(self, reqPOST):
        errors = {}
        if len(reqPOST['title']) < 3:
            errors['title'] = 'Title requires at least 3 characters.'
        if len(reqPOST['description']) < 3:
            errors['description'] = 'Description requires at least 3 characters.'    
        if len(reqPOST['location']) < 3:
            errors['location'] = 'Location requires at least 3 characters.'
        
        return errors


class User(models.Model):
    first_name=models.TextField()
    last_name=models.TextField()
    email=models.TextField()
    password=models.TextField()
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    objects=UserManager()

    def __str__(self):
        return f'{self.first_name}, {self.last_name}'

class Job(models.Model):
    title=models.TextField()
    description=models.TextField()
    location=models.TextField()
    posted_by = models.ForeignKey(User, related_name='job_submitter', on_delete=CASCADE)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    objects=JobManager()

    def __str__(self):
        return f'<{self.title}, {self.description}, {self.location}, {self.created_at}, {self.id})>'


