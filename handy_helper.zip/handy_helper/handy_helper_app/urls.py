from django.urls import path
from .import views

urlpatterns = [
    path('', views.index), #GET request redirecting
    path('users/create', views.create_user),#make a create_user method now in views.py
    path('dashboard', views.dashboard), #GETrequest to go to the dashboard page
    path('users/login', views.login), #make a login method in views.py
    path('logout', views.logout),
    path('create_job', views.create_job),#create a new job function
    path('new', views.new), #Go to create a new job page
    path('dashboard/<int:job_id>/view', views.view),#Go to view page
    path('dashboard/<int:job_id>/edit', views.edit),#Go to edit page
    path('dashboard/<int:job_id>/delete',views.delete),# delete function
    path('dashboard/<int:job_id>/update', views.update),#function to edit a job
]