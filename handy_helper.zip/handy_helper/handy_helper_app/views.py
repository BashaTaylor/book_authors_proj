from django.shortcuts import render, redirect
import bcrypt
from django.contrib import messages
from .models import *

# Create your views here.
def index(request):
    request.session.flush()
    context = {
        'all_jobs': Job.objects.all()
    }
    return render(request, 'index.html', context)

#Create a user
def create_user(request):
    if request.method == 'POST':
        errors = User.objects.create_validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
            return redirect('/')
        else:
            password = request.POST['password']
            #this is the mambo-jumbo instead of actual password
            pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
            # now create a user in your dataBase
            user = User.objects.create(first_name=request.POST['first_name'],last_name=request.POST['last_name'], email=request.POST['email'], password=pw_hash) #make sure to make this pw_hash
            request.session['user_id'] = user.id
            return redirect('/dashboard')
    return redirect('/')
#Login
def login(request):
    if request.method == 'POST':
        users_with_email = User.objects.filter(email=request.POST['email'])
        if users_with_email:
            user = users_with_email[0]
            if bcrypt.checkpw(request.POST['password'].encode(), user.password.encode()):
                request.session['user_id'] = user.id
                return redirect('/dashboard')
        messages.error(request, 'Email or password are not correct')
    return redirect('/') 

#making a method called dashboard
def dashboard(request):
    current_user = User.objects.get(id=request.session['user_id'])
    context = {
        'this_user': current_user,
        'all_jobs' : Job.objects.all().order_by('-created_at')
        # 'my_favorites' : current_user.favorite_quotes.all()
    }
    return render(request, 'dashboard.html', context)

#logout
def logout(request):
    request.session.flush()
    return redirect('/')

#Go to the create new job page
def new(request):
    current_user = User.objects.get(id=request.session['user_id'])
    context = {
        'this_user': current_user,
        'all_jobs' : Job.objects.all(),
        # 'my_favorites' : current_user.favorite_quotes.all()
    }
    return render(request, 'new.html', context)

#Create a new job 
def create_job(request):
    if request.method != 'POST' or 'user_id' not in request.session:
        return redirect('')
    errors = Job.objects.job_validator(request.POST)
    print(errors)
    if len(errors)>0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/new')
    #we need to create a new job in database
    Job.objects.create(
        title = request.POST['title'],
        description = request.POST['description'],
        location = request.POST['location'],
        posted_by = User.objects.get(id=request.session['user_id'])
    )
    return redirect('/dashboard')

def view(request, job_id):
    one_job = Job.objects.get(id=job_id)
    context = {
        'job': one_job,
        'this_user': User.objects.get(id=request.session['user_id'])
    }
    return render(request, 'view.html', context)


def edit(request, job_id):
    if request.method == 'GET':
        one_job = Job.objects.get(id=job_id) 
        context = {
            'job': one_job,
            'this_user': User.objects.get(id=request.session['user_id'])
        }
        return render(request, 'edit.html', context)    

def delete(request, job_id):
    if request.method == 'POST':
        job_to_delete = Job.objects.get(id=job_id)
        job_to_delete.delete()
    return redirect('/dashboard')

def update(request, job_id):
    update_job = Job.objects.get(id=job_id)
    update_job.title = request.POST['title']
    update_job.description = request.POST['description']
    update_job.location = request.POST['location']
    errors = Job.objects.job_validator(request.POST)
    print(errors)
    if len(errors)>0:
        for key, value in errors.items():
            messages.error(request, value)
        context = {
            'job': update_job,
            'this_user': User.objects.get(id=request.session['user_id'])
        }
        return render(request, 'edit.html', context)
    update_job.save()
    return redirect('/dashboard')


