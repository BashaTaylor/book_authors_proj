from django.apps import AppConfig


class HogwartsAppConfig(AppConfig):
    name = 'hogwarts_app'
