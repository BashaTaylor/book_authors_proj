from django.apps import AppConfig


class SemiRestfulAppConfig(AppConfig):
    name = 'semi_restful_validated_app'
